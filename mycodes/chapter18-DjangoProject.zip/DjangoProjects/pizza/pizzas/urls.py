from django.conf.urls import url
from . import views


urlpatterns = [
    # 主页
    url(r'^$', views.index, name='index'),

    # 所有pizza种类
    url(r'^pizzas/$', views.pizzas, name='pizzas'),

    # 特定pizza页面
    url(r'^pizzas/(?P<pizza_id>\d+)/$', views.pizza, name='pizza'),

    # 一次添加一种pizza
    url(r'^add_pizza/$', views.add_pizza, name='add_pizza'),

    # 添加某种披萨的配料， url：add_topping + 披萨id
    url(r'^add_topping/(?P<pizza_id>\d+)/$', views.add_topping, name='add_topping'),

    # 编辑配料， url： edit_topping + 配料id
    url(r'^edit_topping/(?P<topping_id>\d+)/$', views.edit_topping, name='edit_topping'),
]