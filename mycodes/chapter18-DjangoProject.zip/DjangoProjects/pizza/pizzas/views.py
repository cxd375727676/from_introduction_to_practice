from django.shortcuts import render
from .models import Pizza, Topping
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from .forms import PizzaForm, ToppingForm

def index(request):
    return render(request, 'pizzas/index.html')


def pizzas(request):
    pizzas = Pizza.objects.order_by('date_added')
    context = {'pizzas': pizzas}
    return render(request, 'pizzas/pizzas.html', context)


def pizza(request, pizza_id):
    pizza = Pizza.objects.get(id=pizza_id)
    toppings = pizza.topping_set.order_by('-date_added')
    context = {'pizza': pizza, 'toppings': toppings}
    return render(request, 'pizzas/pizza.html', context)


def add_pizza(request):
    if request.method != 'POST':
        form = PizzaForm()
    else:
        form = PizzaForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('pizzas:pizzas'))

    context = {'form': form}
    return render(request, 'pizzas/add_pizza.html', context)


def add_topping(request, pizza_id):
    pizza = Pizza.objects.get(id=pizza_id)
    if request.method != 'POST':
        form = ToppingForm()
    else:
        form = ToppingForm(request.POST)
        if form.is_valid():
            new_topping = form.save(commit=False)
            new_topping.pizza = pizza
            new_topping.save()
            return HttpResponseRedirect(reverse('pizzas:pizza', args=[pizza_id]))

    context = {'pizza': pizza, 'form': form}
    return render(request, 'pizzas/add_topping.html', context)


def edit_topping(request, topping_id):
    topping = Topping.objects.get(id=topping_id)    # 已有的topping
    pizza = topping.pizza                           # 所属pizza
    if request.method != 'POST':
        form = ToppingForm(instance=topping)
    else:
        form = ToppingForm(instance=topping, data=request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('pizzas:pizza', args=[pizza.id]))

    context = {'pizza':pizza, 'topping':topping, 'form':form}
    return render(request, 'pizzas/edit_topping.html', context)

