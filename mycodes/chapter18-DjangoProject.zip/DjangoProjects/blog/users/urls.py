from django.conf.urls import url
from django.contrib.auth.views import login    # 已有登录视图，直接用
from . import views


urlpatterns = [
    # 登录
    url(r'^login/$', login, {'template_name': 'users/login.html'}, name='login'),

    # 提示登录
    url(r'^login_reminder/$', views.login_reminder, name='login_reminder'),

    # 注销
    url(r'^logout/$', views.logout_view, name='logout'),

    # 新用户注册
    url(r'^register/$', views.register, name='register'),
]