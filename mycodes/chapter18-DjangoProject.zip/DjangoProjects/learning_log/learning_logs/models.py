from django.db import models
from django.contrib.auth.models import User

class Topic(models.Model):
    """记录主题、时间作为属性值， 返回主题（在网页Topic栏目下列示）"""
    text = models.CharField(max_length=200)
    date_added = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User)

    def __str__(self):
        return self.text


class Entry(models.Model):
    """创建一条记录时，可先选择主题再输入内容， 返回内容前50个字符（Entry下列示）"""
    topic = models.ForeignKey(Topic)   # 创建每个主题时都分配了一个键；将每个条目关联到特定主题
    text = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        """嵌套类， 网页会用Entries表示多个条目， 否则是 Entrys """
        verbose_name_plural = 'entries'

    def __str__(self):
        text = self.text
        if len(text) > 50:
            return text[:50] + "..."
        else:
            return text


